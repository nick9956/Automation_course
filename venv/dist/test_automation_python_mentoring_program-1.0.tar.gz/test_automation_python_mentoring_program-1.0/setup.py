from setuptools import setup

setup(name='test_automation_python_mentoring_program',
      version='1.0',
      description='setup.py file for my project with the hometasks',
      author='Mykola Rudym',
      author_email='mykola_rudym@epam.com',
      packages=['module_1', 'module_2', 'module_3'],
     )
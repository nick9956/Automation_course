from setuptools import setup

setup(name='Test Automation (Python) Mentoring program hometasks',
      version='1.0',
      description='setup.py file for my project with the hometasks',
      author='Mykola Rudym',
      author_email='mykola_rudym@epam.com',
      packages=['module_1', 'module_2', 'module_3'],
     )